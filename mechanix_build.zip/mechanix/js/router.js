/* ─────────────────────────────────────────
   router.js — navegação entre páginas
───────────────────────────────────────── */

const PAGES = {};

/** Registra uma página pelo nome */
function registerPage(name, renderFn) {
  PAGES[name] = renderFn;
}

/** Navega para uma página */
function goTo(name, el) {
  // Remove estado ativo de todos
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(t => t.classList.remove('active'));

  // Ativa item do menu
  el.classList.add('active');
  document.getElementById('pageTitle').textContent = el.dataset.label;

  // Renderiza a página se ainda não foi montada
  const app = document.getElementById('app');
  let pageEl = document.getElementById('pg-' + name);

  if (!pageEl) {
    pageEl = document.createElement('div');
    pageEl.id = 'pg-' + name;
    pageEl.className = 'page';
    pageEl.innerHTML = PAGES[name] ? PAGES[name]() : '<p style="padding:28px;color:var(--muted)">Página em construção.</p>';
    app.appendChild(pageEl);

    // Inicializa lógica específica da página após inserção no DOM
    if (window['init_' + name]) window['init_' + name]();
  }

  pageEl.classList.add('active');
}

/** Relógio no topbar */
function updateClock() {
  const n = new Date();
  const el = document.getElementById('clk');
  if (el) el.textContent = String(n.getHours()).padStart(2,'0') + ':' + String(n.getMinutes()).padStart(2,'0');
}
