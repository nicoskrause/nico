/* ─────────────────────────────────────────
   app.js — bootstrap e helpers globais
───────────────────────────────────────── */

/* ── Helpers de UI ── */

function pill(text, cls) {
  return `<span class="pill ${cls}" style="font-size:11px"><span class="dot"></span>${text}</span>`;
}

function fidHtml(n) {
  let h = '<div class="fid">';
  for (let i = 1; i <= 5; i++) h += `<div class="fd ${i <= n ? 'on' : ''}"></div>`;
  return h + '</div>';
}

function statusPill(s) {
  const map = { Ativo: 'p-green', Inativo: 'p-red', 'Aguard.': 'p-yellow' };
  return pill(s, map[s] || 'p-muted');
}

function stockStatus(q, m) {
  if (q === 0)  return { cls: 'sb-out', txt: 'Sem estoque' };
  if (q <= m)   return { cls: 'sb-low', txt: 'Estoque baixo' };
  return              { cls: 'sb-ok',  txt: 'Ok' };
}

function stockColor(q, m) {
  if (q === 0) return 'var(--red)';
  if (q <= m)  return 'var(--yellow)';
  return 'var(--green)';
}

/* ── Bootstrap ── */

document.addEventListener('DOMContentLoaded', () => {
  // Inicia relógio
  updateClock();
  setInterval(updateClock, 1000);

  // Abre página inicial
  const firstNav = document.querySelector('.nav-item.active');
  if (firstNav) goTo('equipes', firstNav);
});
