/* ─────────────────────────────────────────
   data.js — dados mock centralizados
   Substitua por chamadas fetch() à sua API
───────────────────────────────────────── */

const DATA = {

  equipe: [
    { init:'RS', nome:'Ricardo Santos',  cargo:'Mecânico Sênior',          status:'Em serviço', statusCls:'p-green',  os:18, av:'4.9', fat:16800, meta:20000, bg:'#fff3eb', cor:'var(--accent)' },
    { init:'MF', nome:'Marcos Ferreira', cargo:'Eletricista Auto',          status:'Em serviço', statusCls:'p-green',  os:14, av:'4.7', fat:13000, meta:20000, bg:'#e6f0f8', cor:'var(--blue)'   },
    { init:'AL', nome:'Ana Lima',        cargo:'Funilaria',                  status:'Disponível', statusCls:'p-yellow', os:11, av:'5.0', fat:12000, meta:20000, bg:'#e6f4ec', cor:'var(--green)'  },
    { init:'JP', nome:'João Pereira',    cargo:'Mecânico Geral',             status:'Folga',      statusCls:'p-muted',  os:9,  av:'4.5', fat:7400,  meta:15000, bg:'#fcecea', cor:'var(--red)'    },
    { init:'PC', nome:'Paulo Costa',     cargo:'Alinhamento / Balanceamento',status:'Em serviço', statusCls:'p-green',  os:22, av:'4.8', fat:18000, meta:20000, bg:'#fff3eb', cor:'var(--accent)' },
    { init:'LM', nome:'Larissa Melo',    cargo:'Recepção / OS',              status:'Disponível', statusCls:'p-yellow', os:0,  av:'5.0', fat:0,     meta:0,     bg:'#e6f0f8', cor:'var(--blue)'   },
  ],

  clientes: [
    { nome:'Roberto Alves',   init:'RA', veiculo:'HB20 2022 · ABC-1234',    ultimo:'14/04/2025', proximo:'Out/2025', fid:5, status:'Ativo',   tel:'(51) 9 9999-0001', email:'roberto@email.com',   os:8  },
    { nome:'Fernanda Ramos',  init:'FR', veiculo:'Onix 2021 · DEF-5678',    ultimo:'14/04/2025', proximo:'Out/2025', fid:4, status:'Ativo',   tel:'(51) 9 9999-0002', email:'fernanda@email.com',  os:5  },
    { nome:'Thiago Dias',     init:'TD', veiculo:'Compass 2020 · GHI-9012', ultimo:'14/04/2025', proximo:'Nov/2025', fid:3, status:'Aguard.', tel:'(51) 9 9999-0003', email:'thiago@email.com',    os:3  },
    { nome:'Lucas Martins',   init:'LM', veiculo:'Sandero 2023 · JKL-3456', ultimo:'14/04/2025', proximo:'Out/2025', fid:5, status:'Ativo',   tel:'(51) 9 9999-0004', email:'lucas@email.com',     os:12 },
    { nome:'Camila Souza',    init:'CS', veiculo:'Fox 2018 · MNO-7890',     ultimo:'14/04/2025', proximo:'Dez/2025', fid:2, status:'Ativo',   tel:'(51) 9 9999-0005', email:'camila@email.com',    os:4  },
    { nome:'Beatriz Nunes',   init:'BN', veiculo:'T-Cross 2022 · PQR-1234', ultimo:'12/04/2025', proximo:'Out/2025', fid:4, status:'Ativo',   tel:'(51) 9 9999-0006', email:'beatriz@email.com',   os:6  },
    { nome:'André Lima',      init:'AL', veiculo:'Kicks 2023 · STU-5678',   ultimo:'14/04/2025', proximo:'Set/2025', fid:3, status:'Ativo',   tel:'(51) 9 9999-0007', email:'andre@email.com',     os:3  },
    { nome:'Marcos Oliveira', init:'MO', veiculo:'Gol 2017 · VWX-9012',     ultimo:'05/04/2025', proximo:'Jul/2025', fid:5, status:'Ativo',   tel:'(51) 9 9999-0008', email:'marcos@email.com',    os:15 },
    { nome:'Patrícia Gomes',  init:'PG', veiculo:'Argo 2021 · YZA-3456',    ultimo:'01/04/2025', proximo:'Out/2025', fid:1, status:'Inativo', tel:'(51) 9 9999-0009', email:'patricia@email.com',  os:1  },
    { nome:'Rafael Costa',    init:'RC', veiculo:'Pulse 2023 · BCD-7890',   ultimo:'28/03/2025', proximo:'Set/2025', fid:3, status:'Ativo',   tel:'(51) 9 9999-0010', email:'rafael@email.com',    os:4  },
  ],

  pecas: [
    { nome:'Pastilha de freio dianteira', cat:'Freios',    qtd:8,  min:4,  preco:45,  uso:'14/04/2025' },
    { nome:'Filtro de óleo - Honda',      cat:'Filtros',   qtd:12, min:6,  preco:22,  uso:'13/04/2025' },
    { nome:'Vela de ignição NGK',         cat:'Motor',     qtd:3,  min:8,  preco:18,  uso:'12/04/2025' },
    { nome:'Correia dentada Gates',       cat:'Motor',     qtd:2,  min:3,  preco:95,  uso:'10/04/2025' },
    { nome:'Fluido de freio DOT 4',       cat:'Fluidos',   qtd:6,  min:4,  preco:28,  uso:'14/04/2025' },
    { nome:'Óleo motor 5W30 sintético',   cat:'Fluidos',   qtd:0,  min:10, preco:35,  uso:'14/04/2025' },
    { nome:'Sensor ABS traseiro',         cat:'Elétrica',  qtd:1,  min:2,  preco:180, uso:'14/04/2025' },
    { nome:'Amortecedor Monroe diant.',   cat:'Suspensão', qtd:4,  min:2,  preco:220, uso:'08/04/2025' },
    { nome:'Bomba de combustível',        cat:'Motor',     qtd:2,  min:2,  preco:340, uso:'05/04/2025' },
    { nome:'Filtro de ar esportivo',      cat:'Filtros',   qtd:9,  min:4,  preco:48,  uso:'11/04/2025' },
  ],

  desenvolvimento: [
    { init:'RS', nome:'Ricardo Santos',  bg:'#fff3eb', cor:'var(--accent)', nivel:'Sênior',      certs:['SENAI Mecânica Avançada','NR-12 válida'],          prox:'Diagnóstico Elétrico'   },
    { init:'MF', nome:'Marcos Ferreira', bg:'#e6f0f8', cor:'var(--blue)',   nivel:'Especialista', certs:['Certificação Bosch Elétrica','Injeção Eletrônica'], prox:'Veículos Elétricos'     },
    { init:'AL', nome:'Ana Lima',        bg:'#e6f4ec', cor:'var(--green)',  nivel:'Pleno',        certs:['3M Funilaria','NR-12 válida'],                      prox:'Pintura Avançada'       },
    { init:'JP', nome:'João Pereira',    bg:'#fcecea', cor:'var(--red)',    nivel:'Auxiliar',     certs:['NR-12 vence Jun/25'],                               prox:'Renovação NR-12 urgente'},
  ],

};
