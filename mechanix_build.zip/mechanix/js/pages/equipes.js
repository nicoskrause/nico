/* ─────────────────────────────────────────
   pages/equipes.js
───────────────────────────────────────── */
registerPage('equipes', () => `
<div class="eq-hero">
  <div>
    <div class="eq-hero-title">Equipe da Oficina</div>
    <div class="eq-hero-sub">6 colaboradores · Abril 2025</div>
  </div>
  <div class="eq-stats-row">
    <div style="text-align:right"><div class="eq-stat-val" style="color:var(--green)">3</div><div class="eq-stat-label">Em serviço</div></div>
    <div style="text-align:right"><div class="eq-stat-val" style="color:var(--yellow)">2</div><div class="eq-stat-label">Disponíveis</div></div>
    <div style="text-align:right"><div class="eq-stat-val" style="color:var(--muted)">1</div><div class="eq-stat-label">Folga</div></div>
    <div style="text-align:right"><div class="eq-stat-val" style="color:var(--accent)">R$ 67k</div><div class="eq-stat-label">Fat. influenciado</div></div>
  </div>
</div>
<div class="eq-body"><div class="eq-grid" id="equipeGrid"></div></div>
`);

function init_equipes() {
  document.getElementById('equipeGrid').innerHTML = DATA.equipe.map(m => {
    const pct = m.meta > 0 ? Math.round(m.fat / m.meta * 100) : null;
    const pc  = pct !== null ? (pct >= 80 ? 'var(--green)' : pct >= 50 ? 'var(--yellow)' : 'var(--red)') : 'var(--muted)';
    const fatBar = m.meta > 0 ? `
      <div class="eq-fat-bar">
        <div class="eq-fat-label"><span>Fat. influenciado</span><span style="color:${pc};font-weight:600">${pct}%</span></div>
        <div class="pbar"><div class="pfill" style="width:${Math.min(pct,100)}%;background:${pc}"></div></div>
        <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--muted);margin-top:3px">
          <span>R$ ${m.fat.toLocaleString('pt-BR')}</span><span>Meta R$ ${m.meta.toLocaleString('pt-BR')}</span>
        </div>
      </div>` : `<div class="eq-fat-bar"><div style="font-size:11px;color:var(--muted)">Sem meta de faturamento</div></div>`;
    return `
    <div class="eq-card">
      <div class="eq-card-top">
        <div class="eq-avatar" style="background:${m.bg};color:${m.cor}">${m.init}</div>
        <div>
          <div style="font-size:14px;font-weight:600;margin-bottom:2px">${m.nome}</div>
          <div style="font-size:11px;color:var(--muted);margin-bottom:6px">${m.cargo}</div>
          <span class="pill ${m.statusCls}"><span class="dot"></span>${m.status}</span>
        </div>
      </div>
      <div class="eq-card-stats">
        <div class="eq-stat-cell"><span class="val">${m.os}</span>OS / mês</div>
        <div class="eq-stat-cell"><span class="val">⭐ ${m.av}</span>Avaliação</div>
        <div class="eq-stat-cell"><span class="val" style="color:var(--accent)">R$ ${Math.round(m.fat/1000)}k</span>Fat.</div>
      </div>
      ${fatBar}
    </div>`;
  }).join('');
}
