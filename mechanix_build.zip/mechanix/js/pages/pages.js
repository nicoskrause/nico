/* ─────────────────────────────────────────
   pages/metas.js
───────────────────────────────────────── */
registerPage('metas', () => `
<div class="meta-layout">
  <div class="meta-left">
    <div style="font-family:var(--font-display);font-size:28px;font-weight:800;margin-bottom:3px">Metas — Abril 2025</div>
    <div style="font-size:12px;color:var(--muted);margin-bottom:18px">Acompanhamento de desempenho individual e coletivo</div>
    <div class="kpi-grid kpi-g3" style="margin-bottom:22px">
      <div class="kbox"><div class="kbox-lbl">Meta mensal</div><div class="kbox-val">R$ 95k</div><div class="kbox-sub">Objetivo do mês</div></div>
      <div class="kbox"><div class="kbox-lbl">Realizado</div><div class="kbox-val" style="color:var(--accent)">R$ 67k</div><div class="kbox-sub up">↑ 8% vs março</div></div>
      <div class="kbox"><div class="kbox-lbl">Atingimento</div><div class="kbox-val" style="color:var(--yellow)">71%</div><div class="kbox-sub">16 dias restantes</div></div>
    </div>
    <div class="slbl">Progresso por mecânico</div>
    ${[
      {nome:'Paulo Costa',   pct:90, real:'R$ 18.000', meta:'R$ 20.000', cor:'var(--green)',  label:'Ótimo ritmo'},
      {nome:'Ricardo Santos',pct:84, real:'R$ 16.800', meta:'R$ 20.000', cor:'var(--green)',  label:'No prazo'},
      {nome:'Marcos Ferreira',pct:65,real:'R$ 13.000', meta:'R$ 20.000', cor:'var(--yellow)', label:'Atenção'},
      {nome:'Ana Lima',      pct:60, real:'R$ 12.000', meta:'R$ 20.000', cor:'var(--accent)', label:'Atenção'},
      {nome:'João Pereira',  pct:37, real:'R$ 7.400',  meta:'R$ 15.000', cor:'var(--red)',    label:'De folga este mês'},
    ].map(m => `
    <div class="meta-item">
      <div class="meta-row-hdr"><div class="meta-name">${m.nome}</div><div class="meta-pct" style="color:${m.cor}">${m.pct}%</div></div>
      <div class="pbar"><div class="pfill" style="width:${m.pct}%;background:${m.cor}"></div></div>
      <div class="meta-vals"><span>${m.real} / ${m.meta}</span><span style="color:${m.cor}">${m.label}</span></div>
    </div>`).join('')}
  </div>
  <div class="meta-right">
    <div class="panel-title">Ranking do mês</div>
    ${[
      {n:1, nome:'Paulo Costa',    os:'22', val:'R$ 18k', cor:'var(--accent)'},
      {n:2, nome:'Ricardo Santos', os:'18', val:'R$ 16.8k'},
      {n:3, nome:'Marcos Ferreira',os:'14', val:'R$ 13k'},
      {n:4, nome:'Ana Lima',       os:'11', val:'R$ 12k'},
      {n:5, nome:'João Pereira',   os:'9',  val:'R$ 7.4k'},
    ].map(r => `
    <div class="rank-item">
      <div class="rank-num" style="color:${r.cor||'var(--border)'}">${r.n}</div>
      <div><div class="rank-name">${r.nome}</div><div style="font-size:11px;color:var(--muted)">${r.os} OS</div></div>
      <div class="rank-val">${r.val}</div>
    </div>`).join('')}
    <div style="margin-top:20px">
      <div class="panel-title">Meta geral</div>
      <div style="background:var(--bg2);border:1px solid var(--border);border-radius:10px;padding:14px 16px">
        <div style="display:flex;justify-content:space-between;margin-bottom:8px">
          <span style="font-size:13px;font-weight:600">Abril 2025</span>
          <span style="font-family:var(--font-display);font-size:18px;font-weight:700;color:var(--yellow)">71%</span>
        </div>
        <div class="pbar" style="height:9px"><div class="pfill" style="width:71%;background:var(--yellow)"></div></div>
        <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--muted);margin-top:6px"><span>R$ 67.200</span><span>Meta R$ 95.000</span></div>
      </div>
    </div>
  </div>
</div>
`);


/* ─────────────────────────────────────────
   pages/patio.js
───────────────────────────────────────── */
registerPage('patio', () => `
<div class="page-header">
  <div><div class="page-title-lg">Pátio — Visão Kanban</div><div class="page-sub">10 boxes · 14 Abr 2025</div></div>
  <div style="display:flex;gap:14px;font-size:11px;color:var(--muted)">
    <span><span style="width:8px;height:8px;border-radius:2px;display:inline-block;background:var(--muted);margin-right:4px"></span>Aguardando</span>
    <span><span style="width:8px;height:8px;border-radius:2px;display:inline-block;background:var(--blue);margin-right:4px"></span>Em manutenção</span>
    <span><span style="width:8px;height:8px;border-radius:2px;display:inline-block;background:var(--yellow);margin-right:4px"></span>Aguard. peça</span>
    <span><span style="width:8px;height:8px;border-radius:2px;display:inline-block;background:var(--green);margin-right:4px"></span>Pronto</span>
  </div>
</div>
<div class="kanban">
  <div class="kanban-col">
    <div class="kanban-head" style="color:var(--muted)">Aguardando <span class="kanban-count">2</span></div>
    <div class="kanban-cards">
      ${kcard('BOX 08','','Gol 2019 · Cinza','Marcos Oliveira','Orçamento troca de motor',['Aguardando atribuição'],'Chegou: 13:00','Sem OS')}
      ${kcard('BOX 09','','Argo 2021 · Branco','Patrícia Gomes','Revisão completa',['Aguardando atribuição'],'Chegou: 13:45','Sem OS')}
    </div>
  </div>
  <div class="kanban-col">
    <div class="kanban-head" style="color:var(--blue)">Em manutenção <span class="kanban-count">4</span></div>
    <div class="kanban-cards">
      ${kcard('BOX 02','var(--blue)','Onix 2021 · Branco','Fernanda Ramos','Troca de embreagem + ajuste câmbio',['Marcos F.','Ricardo S.'],'Entrada: 09:00','~3h')}
      ${kcard('BOX 04','var(--blue)','Fox 2018 · Vermelho','Camila Souza','Troca de pastilhas de freio',['Ricardo S.'],'Entrada: 07:45','~1h')}
      ${kcard('BOX 06','var(--blue)','T-Cross 2022 · Branco','Beatriz Nunes','Revisão freios + suspensão',['Ana Lima','Paulo C.'],'Entrada: 11:00','~2h')}
      ${kcard('BOX 07','var(--blue)','Kicks 2023 · Azul','André Lima','Diagnóstico elétrico + multimídia',['Marcos F.','Ricardo S.','Ana Lima'],'Entrada: 12:30','~4h')}
    </div>
  </div>
  <div class="kanban-col">
    <div class="kanban-head" style="color:var(--yellow)">Aguard. peça <span class="kanban-count">1</span></div>
    <div class="kanban-cards">
      ${kcard('BOX 03','var(--yellow)','Compass 2020 · Preto','Thiago Dias','Sensor de ABS — peça em trânsito',['Ricardo S.'],'Entrada: 10:15','amanhã')}
    </div>
  </div>
  <div class="kanban-col">
    <div class="kanban-head" style="color:var(--green)">Pronto p/ entrega <span class="kanban-count">2</span></div>
    <div class="kanban-cards">
      ${kcard('BOX 01','var(--green)','HB20 2022 · Prata','Roberto Alves','Revisão 30k km concluída',['Paulo C.'],'Entrada: 08:30','R$ 580')}
      ${kcard('BOX 05','var(--green)','Sandero 2023 · Cinza','Lucas Martins','Alinhamento e balanceamento',['Paulo C.'],'Entrada: 08:00','R$ 180')}
    </div>
  </div>
</div>
`);

function kcard(box, borderColor, vehicle, client, service, mechs, foot1, foot2) {
  const border = borderColor ? `border-left:3px solid ${borderColor}` : '';
  return `
  <div class="kcard" style="${border}">
    <div style="display:flex;justify-content:space-between;margin-bottom:7px">
      <span class="kcard-box">${box}</span>
      ${foot2 && foot2.startsWith('~') ? `<span style="font-size:11px;color:${borderColor}">${foot2}</span>` : ''}
    </div>
    <div class="kcard-vehicle">${vehicle}</div>
    <div class="kcard-client">${client}</div>
    <div class="kcard-service">${service}</div>
    <div class="kcard-mechs">${mechs.map(m => `<span class="mech-tag">${m}</span>`).join('')}</div>
    <div class="kcard-footer"><span>${foot1}</span><span>${foot2.startsWith('~') ? mechs.length + ' mecânico(s)' : foot2}</span></div>
  </div>`;
}


/* ─────────────────────────────────────────
   pages/clientes.js
───────────────────────────────────────── */
registerPage('clientes', () => `
<div class="cli-layout">
  <div class="cli-main">
    <div class="page-header">
      <div><div class="page-title-lg">Clientes</div><div class="page-sub">10 cadastros</div></div>
      <div style="display:flex;gap:8px;align-items:center">
        <input class="srch" placeholder="Buscar..." id="cliSearch" oninput="filterCli()">
        <button class="btn-primary">+ Novo</button>
      </div>
    </div>
    <div style="overflow-x:auto">
      <table>
        <thead><tr><th>Cliente</th><th>Veículo</th><th>Último serviço</th><th>Próx. revisão</th><th>Fidelidade</th><th>Status</th></tr></thead>
        <tbody id="cliTbody"></tbody>
      </table>
    </div>
  </div>
  <div class="cli-detail" id="cliDetail"><div class="detail-placeholder">Selecione um cliente<br>para ver os detalhes</div></div>
</div>
`);

function init_clientes() {
  renderCli(DATA.clientes);
}

function renderCli(list) {
  document.getElementById('cliTbody').innerHTML = list.map(c => `
    <tr onclick="showCli(${DATA.clientes.indexOf(c)})" id="cr${DATA.clientes.indexOf(c)}">
      <td style="font-weight:600">${c.nome}</td>
      <td style="color:var(--muted);font-size:12px">${c.veiculo}</td>
      <td style="color:var(--muted)">${c.ultimo}</td>
      <td>${c.proximo}</td>
      <td>${fidHtml(c.fid)}</td>
      <td>${statusPill(c.status)}</td>
    </tr>`).join('');
}

function showCli(i) {
  document.querySelectorAll('#cliTbody tr').forEach(r => r.classList.remove('selected'));
  const row = document.getElementById('cr' + i);
  if (row) row.classList.add('selected');
  const c = DATA.clientes[i];
  document.getElementById('cliDetail').innerHTML = `
    <div class="detail-avatar">${c.init}</div>
    <div class="detail-name">${c.nome}</div>
    <div style="font-size:12px;color:var(--muted);margin-bottom:14px">${c.veiculo}</div>
    <div class="detail-row"><span class="lbl">Telefone</span><span>${c.tel}</span></div>
    <div class="detail-row"><span class="lbl">E-mail</span><span style="font-size:11px">${c.email}</span></div>
    <div class="detail-row"><span class="lbl">Último serviço</span><span>${c.ultimo}</span></div>
    <div class="detail-row"><span class="lbl">Próxima revisão</span><span>${c.proximo}</span></div>
    <div class="detail-row"><span class="lbl">OS realizadas</span><span style="color:var(--accent);font-weight:700">${c.os}</span></div>
    <div class="detail-row"><span class="lbl">Status</span>${statusPill(c.status)}</div>
    <div style="margin-top:11px"><div style="font-size:10px;color:var(--muted);margin-bottom:4px">Fidelidade</div>${fidHtml(c.fid)}</div>`;
}

function filterCli() {
  const q = document.getElementById('cliSearch').value.toLowerCase();
  renderCli(DATA.clientes.filter(c => c.nome.toLowerCase().includes(q) || c.veiculo.toLowerCase().includes(q)));
}


/* ─────────────────────────────────────────
   pages/faturamento.js
───────────────────────────────────────── */
registerPage('faturamento', () => `
<div class="fat-layout">
  <div class="fat-left">
    <div style="font-size:11px;color:var(--muted);margin-bottom:5px;text-transform:uppercase;letter-spacing:.5px;font-weight:600">Faturamento do mês</div>
    <div class="fat-big">R$ 67.200</div>
    <div class="fat-big-lbl">Abril 2025 · 71% da meta atingida</div>
    <div class="kpi-grid kpi-g2" style="margin-bottom:20px">
      <div class="kbox"><div class="kbox-lbl">Hoje</div><div class="kbox-val">R$ 3.820</div><div class="kbox-sub up">↑ 12% vs ontem</div></div>
      <div class="kbox"><div class="kbox-lbl">Esta semana</div><div class="kbox-val">R$ 18.450</div><div class="kbox-sub up">↑ 5%</div></div>
      <div class="kbox"><div class="kbox-lbl">Ticket médio</div><div class="kbox-val">R$ 620</div><div class="kbox-sub up">↑ 3% vs março</div></div>
      <div class="kbox"><div class="kbox-lbl">OS pagas</div><div class="kbox-val">87</div><div class="kbox-sub" style="color:var(--muted)">de 98 emitidas</div></div>
    </div>
    <div class="slbl">Evolução 2025</div>
    <div class="chart-wrap"><canvas id="fc" role="img" aria-label="Faturamento mensal 2025">Jan:72k Fev:68.5k Mar:62.3k Abr:67.2k Meta:95k</canvas></div>
  </div>
  <div class="fat-right">
    <div class="panel-title">Últimas OS</div>
    ${[
      {nome:'Roberto Alves',  os:'#4821',veic:'HB20',serv:'Revisão 30k', val:'R$ 580',  st:'p-green',  stxt:'Pago'},
      {nome:'Fernanda Ramos', os:'#4820',veic:'Onix', serv:'Embreagem',  val:'R$ 1.200',st:'p-yellow', stxt:'Aberto'},
      {nome:'Lucas Martins',  os:'#4819',veic:'Sandero',serv:'Alinhamento',val:'R$ 180',st:'p-green',  stxt:'Pago'},
      {nome:'Thiago Dias',    os:'#4818',veic:'Compass',serv:'ABS',       val:'R$ 890', st:'p-red',    stxt:'Pendente'},
      {nome:'Camila Souza',   os:'#4817',veic:'Fox',  serv:'Pastilhas',  val:'R$ 420',  st:'p-green',  stxt:'Pago'},
      {nome:'Beatriz Nunes',  os:'#4816',veic:'T-Cross',serv:'Freios',   val:'R$ 760',  st:'p-yellow', stxt:'Aberto'},
      {nome:'André Lima',     os:'#4815',veic:'Kicks',serv:'Elétrico',   val:'R$ 750',  st:'p-yellow', stxt:'Aberto'},
      {nome:'Marcos Oliveira',os:'#4814',veic:'Gol',  serv:'Freios',    val:'R$ 340',  st:'p-green',  stxt:'Pago'},
    ].map(o => `
    <div class="os-item">
      <div><div class="os-info-main">${o.nome}</div><div class="os-info-sub">OS ${o.os} · ${o.veic} · ${o.serv}</div></div>
      <div style="text-align:right"><div class="os-val">${o.val}</div><span class="pill ${o.st}" style="font-size:10px;margin-top:3px;display:inline-flex">${o.stxt}</span></div>
    </div>`).join('')}
  </div>
</div>
`);

function init_faturamento() {
  new Chart(document.getElementById('fc').getContext('2d'), {
    type: 'line',
    data: {
      labels: ['Jan', 'Fev', 'Mar', 'Abr*'],
      datasets: [
        { label:'Realizado', data:[72000,68500,62300,67200], borderColor:'#d06a10', backgroundColor:'rgba(208,106,16,0.06)', borderWidth:2, pointBackgroundColor:'#d06a10', pointRadius:4, fill:true, tension:.35 },
        { label:'Meta',      data:[80000,80000,80000,95000], borderColor:'#d0cdc8', borderDash:[5,4], borderWidth:1.5, pointRadius:0, fill:false, tension:0 }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { color:'rgba(0,0,0,0.04)' }, ticks: { color:'#8a8880', font:{ size:11 } } },
        y: { grid: { color:'rgba(0,0,0,0.04)' }, ticks: { color:'#8a8880', font:{ size:11 }, callback: v => 'R$' + Math.round(v/1000) + 'k' } }
      }
    }
  });
}


/* ─────────────────────────────────────────
   pages/estoque.js
───────────────────────────────────────── */
registerPage('estoque', () => `
<div class="estoque-layout">
  <div class="estoque-main">
    <div class="page-header">
      <div><div class="page-title-lg">Estoque de Peças</div><div class="page-sub">42 itens · 3 em alerta</div></div>
      <div style="display:flex;gap:8px;align-items:center">
        <input class="srch" placeholder="Buscar peça..." id="esqSearch" oninput="filterEstoque()">
        <button class="btn-primary">+ Nova peça</button>
      </div>
    </div>
    <div style="overflow-x:auto">
      <table>
        <thead><tr><th>Peça</th><th>Categoria</th><th>Qtd. atual</th><th>Mínimo</th><th>Status</th><th>Custo</th><th>Últ. uso</th></tr></thead>
        <tbody id="esqTbody"></tbody>
      </table>
    </div>
  </div>
  <div class="estoque-detail" id="esqDetail"><div class="detail-placeholder">Selecione uma peça<br>para ver o histórico</div></div>
</div>
`);

function init_estoque() { renderEstoque(DATA.pecas); }

function renderEstoque(list) {
  document.getElementById('esqTbody').innerHTML = list.map(p => {
    const s   = stockStatus(p.qtd, p.min);
    const pct = Math.min(Math.round(p.qtd / Math.max(p.min * 2, 1) * 100), 100);
    return `<tr onclick="showPeca('${p.nome}')">
      <td style="font-weight:600">${p.nome}</td>
      <td style="color:var(--muted)">${p.cat}</td>
      <td><span style="font-weight:600">${p.qtd}</span><div class="progress-mini" style="width:60px"><div class="pm-fill" style="width:${pct}%;background:${stockColor(p.qtd,p.min)}"></div></div></td>
      <td style="color:var(--muted)">${p.min}</td>
      <td><span class="stock-badge ${s.cls}">${s.txt}</span></td>
      <td>R$ ${p.preco.toFixed(2)}</td>
      <td style="color:var(--muted)">${p.uso}</td>
    </tr>`;
  }).join('');
}

function showPeca(nome) {
  const p = DATA.pecas.find(x => x.nome === nome); if (!p) return;
  const s = stockStatus(p.qtd, p.min);
  document.getElementById('esqDetail').innerHTML = `
    <div style="font-size:15px;font-weight:600;margin-bottom:3px">${p.nome}</div>
    <div style="font-size:11px;color:var(--muted);margin-bottom:14px">${p.cat}</div>
    <div class="detail-row"><span class="lbl">Qtd. atual</span><span style="font-weight:700;color:${stockColor(p.qtd,p.min)}">${p.qtd} unid.</span></div>
    <div class="detail-row"><span class="lbl">Estoque mínimo</span><span>${p.min} unid.</span></div>
    <div class="detail-row"><span class="lbl">Status</span><span class="stock-badge ${s.cls}">${s.txt}</span></div>
    <div class="detail-row"><span class="lbl">Preço de custo</span><span>R$ ${p.preco.toFixed(2)}</span></div>
    <div class="detail-row"><span class="lbl">Último uso</span><span>${p.uso}</span></div>
    ${p.qtd <= p.min ? `<div style="background:#fdf3d0;border-radius:8px;padding:11px;margin-top:14px;border-left:3px solid var(--yellow)"><div style="font-size:11px;font-weight:600;color:var(--yellow);margin-bottom:2px">Reposição necessária</div><div style="font-size:11px;color:var(--muted)">Sugestão: pedir ${p.min*3} unidades</div></div>` : ''}
  `;
}

function filterEstoque() {
  const q = document.getElementById('esqSearch').value.toLowerCase();
  renderEstoque(DATA.pecas.filter(p => p.nome.toLowerCase().includes(q) || p.cat.toLowerCase().includes(q)));
}


/* ─────────────────────────────────────────
   pages/precificacao.js
───────────────────────────────────────── */
registerPage('precificacao', () => `
<div class="prec-layout">
  <div class="prec-left">
    <div style="font-family:var(--font-display);font-size:28px;font-weight:800;margin-bottom:3px">Precificação de Serviços</div>
    <div style="font-size:12px;color:var(--muted);margin-bottom:20px">Calcule o preço justo e visualize sua margem em tempo real</div>
    <div class="card" style="margin-bottom:18px">
      <div style="font-size:11px;font-weight:700;margin-bottom:14px;color:var(--muted);text-transform:uppercase;letter-spacing:.5px">Calculadora de OS</div>
      <div class="calc-row"><span class="calc-lbl">Custo das peças</span><input class="calc-input" id="c_pecas" type="number" value="180" oninput="calcPreco()"><span style="font-size:12px;color:var(--muted)">R$</span></div>
      <div class="calc-row"><span class="calc-lbl">Horas trabalhadas</span><input class="calc-input" id="c_horas" type="number" value="2" oninput="calcPreco()"><span style="font-size:12px;color:var(--muted)">h</span></div>
      <div class="calc-row"><span class="calc-lbl">Custo hora/mecânico</span><input class="calc-input" id="c_hora_val" type="number" value="65" oninput="calcPreco()"><span style="font-size:12px;color:var(--muted)">R$/h</span></div>
      <div class="calc-row"><span class="calc-lbl">Margem desejada</span><input class="calc-input" id="c_margem" type="number" value="40" oninput="calcPreco()"><span style="font-size:12px;color:var(--muted)">%</span></div>
      <hr class="divider">
      <div class="calc-row"><span class="calc-lbl" style="color:var(--muted)">Custo total</span><span class="calc-val" id="r_custo">R$ 310,00</span></div>
      <div class="calc-row"><span class="calc-lbl" style="color:var(--muted)">Lucro bruto</span><span class="calc-val up" id="r_lucro">R$ 124,00</span></div>
      <div class="result-box">
        <div style="font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">Preço sugerido</div>
        <div class="result-val" id="r_preco">R$ 434,00</div>
        <div class="result-lbl" id="r_margem_txt">Margem líquida: 40%</div>
      </div>
    </div>
  </div>
  <div class="prec-right">
    <div class="panel-title">Serviços mais realizados</div>
    ${[
      {nome:'Revisão 30k km',      sub:'2.5h · ~R$ 120', val:'R$ 580',   mg:'mg-high', pct:'52%'},
      {nome:'Troca de embreagem',  sub:'4h · ~R$ 480',   val:'R$ 1.200', mg:'mg-mid',  pct:'38%'},
      {nome:'Alinhamento + balanc.',sub:'1h · sem peças', val:'R$ 180',   mg:'mg-high', pct:'64%'},
      {nome:'Troca de pastilhas',  sub:'1.5h · ~R$ 90',  val:'R$ 420',   mg:'mg-mid',  pct:'45%'},
      {nome:'Diagnóstico elétrico',sub:'3h · variável',   val:'R$ 750',   mg:'mg-mid',  pct:'41%'},
      {nome:'Troca de óleo',       sub:'0.5h · ~R$ 80',  val:'R$ 160',   mg:'mg-low',  pct:'22%'},
    ].map(s => `
    <div class="serv-row">
      <div><div class="serv-name">${s.nome}</div><div class="serv-sub">${s.sub}</div></div>
      <div style="text-align:right"><div style="font-size:13px;font-weight:600">${s.val}</div><span class="margin-pill ${s.mg}">Margem ${s.pct}</span></div>
    </div>`).join('')}
  </div>
</div>
`);

function init_precificacao() { calcPreco(); }

function calcPreco() {
  const p  = parseFloat(document.getElementById('c_pecas').value)    || 0;
  const h  = parseFloat(document.getElementById('c_horas').value)    || 0;
  const hv = parseFloat(document.getElementById('c_hora_val').value) || 0;
  const mg = parseFloat(document.getElementById('c_margem').value)   || 0;
  const custo = p + (h * hv);
  const preco = mg < 100 ? custo / (1 - mg / 100) : custo;
  const lucro = preco - custo;
  document.getElementById('r_custo').textContent     = 'R$ ' + custo.toFixed(2).replace('.', ',');
  document.getElementById('r_lucro').textContent     = 'R$ ' + lucro.toFixed(2).replace('.', ',');
  document.getElementById('r_preco').textContent     = 'R$ ' + preco.toFixed(2).replace('.', ',');
  document.getElementById('r_margem_txt').textContent = 'Margem líquida: ' + Math.round(mg) + '%';
}


/* ─────────────────────────────────────────
   pages/qualidade.js
───────────────────────────────────────── */
registerPage('qualidade', () => `
<div class="qual-layout">
  <div class="qual-left">
    <div style="font-family:var(--font-display);font-size:28px;font-weight:800;margin-bottom:3px">Controle de Qualidade</div>
    <div style="font-size:12px;color:var(--muted);margin-bottom:18px">Taxa de retrabalho por mecânico · Abril 2025</div>
    <div class="kpi-grid kpi-g3" style="margin-bottom:20px">
      <div class="kbox"><div class="kbox-lbl">OS este mês</div><div class="kbox-val">98</div><div class="kbox-sub">total emitidas</div></div>
      <div class="kbox"><div class="kbox-lbl">Retrabalhos</div><div class="kbox-val" style="color:var(--yellow)">6</div><div class="kbox-sub dn">↑ 1 vs março</div></div>
      <div class="kbox"><div class="kbox-lbl">Taxa geral</div><div class="kbox-val" style="color:var(--green)">6,1%</div><div class="kbox-sub">meta: &lt; 8%</div></div>
    </div>
    <div class="slbl">Taxa de retrabalho por mecânico</div>
    ${[
      {init:'PC', bg:'#fff3eb', cor:'var(--accent)', nome:'Paulo Costa',    pct:2,  cor2:'var(--green)'},
      {init:'AL', bg:'#e6f4ec', cor:'var(--green)',  nome:'Ana Lima',       pct:4,  cor2:'var(--green)'},
      {init:'RS', bg:'#fff3eb', cor:'var(--accent)', nome:'Ricardo Santos', pct:6,  cor2:'var(--yellow)'},
      {init:'MF', bg:'#e6f0f8', cor:'var(--blue)',   nome:'Marcos Ferreira',pct:9,  cor2:'var(--yellow)'},
      {init:'JP', bg:'#fcecea', cor:'var(--red)',    nome:'João Pereira',   pct:14, cor2:'var(--red)'},
    ].map(m => `
    <div class="retr-row">
      <div class="retr-avatar" style="background:${m.bg};color:${m.cor}">${m.init}</div>
      <div class="retr-bar-wrap">
        <div class="retr-name"><span>${m.nome}</span><span class="retr-pct" style="color:${m.cor2}">${m.pct}%</span></div>
        <div class="pbar"><div class="pfill" style="width:${m.pct}%;background:${m.cor2}"></div></div>
      </div>
    </div>`).join('')}
  </div>
  <div class="qual-right">
    <div class="panel-title">Alertas de qualidade</div>
    <div class="alert-item" style="border-left:3px solid var(--red)">
      <div class="alert-title">Retrabalho · João Pereira</div>
      <div class="alert-sub">OS #4810 · Gol 2017 · Freio dianteiro refeito em 3 dias</div>
      <div style="font-size:11px;color:var(--red);margin-top:3px">2ª ocorrência este mês</div>
    </div>
    <div class="alert-item" style="border-left:3px solid var(--yellow)">
      <div class="alert-title">Retrabalho · Marcos Ferreira</div>
      <div class="alert-sub">OS #4795 · HB20 · Sensor O2 substituído incorretamente</div>
      <div style="font-size:11px;color:var(--yellow);margin-top:3px">1ª ocorrência este mês</div>
    </div>
    <div style="margin-top:20px">
      <div class="panel-title">Checklist de entrega · OS #4821</div>
      <div style="display:flex;flex-direction:column;gap:7px;font-size:13px">
        ${['Teste de freios realizado','Nível de fluidos verificado','Pressão dos pneus calibrada','Teste de rodagem feito'].map(i =>
          `<div style="display:flex;align-items:center;gap:8px"><span style="color:var(--green)">✓</span>${i}</div>`).join('')}
        <div style="display:flex;align-items:center;gap:8px"><span style="color:var(--yellow)">○</span>Fotos de entrega pendentes</div>
      </div>
    </div>
  </div>
</div>
`);


/* ─────────────────────────────────────────
   pages/desenvolvimento.js
───────────────────────────────────────── */
registerPage('desenvolvimento', () => `
<div class="dev-layout">
  <div class="dev-left">
    <div style="font-family:var(--font-display);font-size:28px;font-weight:800;margin-bottom:3px">Desenvolvimento de Equipe</div>
    <div style="font-size:12px;color:var(--muted);margin-bottom:18px">Capacitações, certificações e plano de carreira</div>
    <div class="kpi-grid kpi-g3" style="margin-bottom:20px">
      <div class="kbox"><div class="kbox-lbl">Treinamentos 2025</div><div class="kbox-val">8</div><div class="kbox-sub">realizados</div></div>
      <div class="kbox"><div class="kbox-lbl">Certificações ativas</div><div class="kbox-val">14</div><div class="kbox-sub">na equipe</div></div>
      <div class="kbox"><div class="kbox-lbl">Próx. vencimento</div><div class="kbox-val" style="color:var(--yellow)">Jun/25</div><div class="kbox-sub">NR-12 · João P.</div></div>
    </div>
    <div class="slbl">Perfil de desenvolvimento</div>
    <div id="devCards"></div>
  </div>
  <div class="dev-right">
    <div class="panel-title">Próximos treinamentos</div>
    ${[
      {titulo:'Diagnóstico veículos elétricos', sub:'SENAI · 16h · Online',          data:'12/05/2025'},
      {titulo:'NR-12 — Segurança em máquinas',  sub:'Renovação obrigatória · 8h',    data:'20/05/2025'},
      {titulo:'Atendimento ao cliente premium', sub:'Interno · 4h · Toda equipe',    data:'02/06/2025'},
      {titulo:'Funilaria e pintura avançada',   sub:'3M Certificado · 24h',          data:'10/06/2025'},
    ].map(t => `<div class="trein-item"><div class="trein-title">${t.titulo}</div><div class="trein-sub">${t.sub}</div><div class="trein-date">${t.data}</div></div>`).join('')}
    <div style="margin-top:18px">
      <div class="panel-title">Plano de carreira — Paulo Costa</div>
      <div style="display:flex;flex-direction:column;gap:5px;font-size:12px">
        <div style="display:flex;align-items:center;gap:7px"><span style="color:var(--green)">✓</span><span style="color:var(--muted)">Mecânico Auxiliar</span></div>
        <div style="display:flex;align-items:center;gap:7px"><span style="color:var(--green)">✓</span><span style="color:var(--muted)">Mecânico Pleno</span></div>
        <div style="display:flex;align-items:center;gap:7px"><span style="color:var(--accent)">→</span><span>Mecânico Sênior <span class="pill p-yellow" style="font-size:10px">em progresso</span></span></div>
        <div style="display:flex;align-items:center;gap:7px"><span style="color:var(--border)">○</span><span style="color:var(--muted)">Chefe de Oficina</span></div>
      </div>
    </div>
  </div>
</div>
`);

function init_desenvolvimento() {
  document.getElementById('devCards').innerHTML = DATA.desenvolvimento.map(d => `
    <div class="dev-card">
      <div class="dev-card-top">
        <div class="dev-avatar" style="background:${d.bg};color:${d.cor}">${d.init}</div>
        <div><div style="font-size:13px;font-weight:600">${d.nome}</div><div style="font-size:11px;color:var(--muted)">Nível: ${d.nivel}</div></div>
        <span class="pill p-muted" style="font-size:10px;margin-left:auto">→ ${d.prox}</span>
      </div>
      ${d.certs.map(c => `<div class="cert-row"><span style="color:var(--green)">✓</span><span>${c}</span><span style="color:var(--muted)">Ativo</span></div>`).join('')}
    </div>`).join('');
}


/* ─────────────────────────────────────────
   pages/relacionamento.js
───────────────────────────────────────── */
registerPage('relacionamento', () => `
<div class="rel-layout">
  <div class="rel-left">
    <div style="font-family:var(--font-display);font-size:28px;font-weight:800;margin-bottom:3px">Relacionamento com Clientes</div>
    <div style="font-size:12px;color:var(--muted);margin-bottom:18px">Régua de comunicação, alertas e pós-venda</div>
    <div class="kpi-grid kpi-g4" style="margin-bottom:20px">
      <div class="kbox"><div class="kbox-lbl">Revisões vencendo</div><div class="kbox-val" style="color:var(--yellow)">7</div><div class="kbox-sub">próximos 30 dias</div></div>
      <div class="kbox"><div class="kbox-lbl">Aniversários</div><div class="kbox-val" style="color:var(--purple)">3</div><div class="kbox-sub">este mês</div></div>
      <div class="kbox"><div class="kbox-lbl">Inativos +90d</div><div class="kbox-val" style="color:var(--red)">12</div><div class="kbox-sub">sem retorno</div></div>
      <div class="kbox"><div class="kbox-lbl">NPS médio</div><div class="kbox-val" style="color:var(--green)">8.7</div><div class="kbox-sub up">↑ 0.3 vs março</div></div>
    </div>
    <div class="slbl">Alertas de ação</div>
    <div class="alerta-card alerta-revisao">
      <div class="alerta-tipo" style="color:var(--yellow)">🔧 Revisão vencendo</div>
      <div class="alerta-cliente">Roberto Alves · HB20 2022</div>
      <div class="alerta-detalhe">Revisão de 6 meses vence em 12 dias</div>
      <div class="alerta-acao"><button class="btn-ghost btn-sm">Enviar WhatsApp</button><button class="btn-ghost btn-sm">Agendar</button></div>
    </div>
    <div class="alerta-card alerta-aniv">
      <div class="alerta-tipo" style="color:var(--purple)">🎂 Aniversário</div>
      <div class="alerta-cliente">Lucas Martins</div>
      <div class="alerta-detalhe">Faz aniversário em 3 dias · 4 anos de cliente · 12 OS</div>
      <div class="alerta-acao"><button class="btn-ghost btn-sm">Parabéns</button><button class="btn-ghost btn-sm">Oferecer desconto</button></div>
    </div>
    <div class="alerta-card alerta-retorno">
      <div class="alerta-tipo" style="color:var(--blue)">💤 Cliente inativo</div>
      <div class="alerta-cliente">Patrícia Gomes</div>
      <div class="alerta-detalhe">Último serviço há 105 dias · Argo 2021</div>
      <div class="alerta-acao"><button class="btn-ghost btn-sm">Enviar oferta</button><button class="btn-ghost btn-sm">Ligar</button></div>
    </div>
  </div>
  <div class="rel-right">
    <div class="panel-title">Funil de retenção</div>
    ${[
      {lbl:'Clientes ativos',  pct:100, val:87},
      {lbl:'Retornaram 90d',   pct:72,  val:63},
      {lbl:'Retornaram 60d',   pct:54,  val:47},
      {lbl:'Indicaram outros', pct:30,  val:26},
    ].map(f => `
    <div class="funil-row">
      <span class="funil-lbl">${f.lbl}</span>
      <div class="funil-bar"><div class="funil-fill" style="width:${f.pct}%"></div></div>
      <span class="funil-val">${f.val}</span>
    </div>`).join('')}
    <div style="margin-top:18px">
      <div class="panel-title">Avaliações recentes</div>
      ${[
        {nome:'Roberto Alves',  stars:'⭐⭐⭐⭐⭐', txt:'"Ótimo atendimento, entregue no prazo!"'},
        {nome:'Lucas Martins',  stars:'⭐⭐⭐⭐⭐', txt:'"Confiança total. Recomendo a amigos."'},
        {nome:'Fernanda Ramos', stars:'⭐⭐⭐⭐',   txt:'"Bom serviço, demorou um pouco mais."'},
      ].map(a => `
      <div style="background:var(--bg2);border:1px solid var(--border);border-radius:8px;padding:9px 11px;margin-bottom:6px">
        <div style="font-size:11px;font-weight:600">${a.nome} ${a.stars}</div>
        <div style="font-size:10px;color:var(--muted);margin-top:2px">${a.txt}</div>
      </div>`).join('')}
    </div>
  </div>
</div>
`);
