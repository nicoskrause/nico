# Mechanix — Sistema de Gestão de Oficinas

Dashboard interno para gestão de oficinas mecânicas.
HTML + CSS + JS puro, sem framework, sem build step.

---

## Estrutura do projeto

```
mechanix/
├── index.html              ← Entrada da aplicação
├── css/
│   ├── base.css            ← Variáveis CSS, reset, tipografia
│   ├── layout.css          ← Sidebar, topbar, main area, páginas
│   ├── components.css      ← Botões, pills, cards, tabelas, inputs
│   └── pages.css           ← Layouts específicos por página
├── js/
│   ├── data.js             ← Dados mock centralizados (substitua por fetch())
│   ├── router.js           ← Sistema de navegação e relógio
│   ├── app.js              ← Bootstrap, helpers globais (pill, fidHtml, etc.)
│   └── pages/
│       ├── equipes.js
│       ├── metas.js
│       ├── patio.js
│       ├── clientes.js
│       ├── faturamento.js
│       ├── estoque.js
│       ├── precificacao.js
│       ├── qualidade.js
│       ├── desenvolvimento.js
│       └── relacionamento.js
└── README.md
```

---

## Como rodar (desenvolvimento local)

### Opção 1 — sem instalar nada (Live Server no VS Code)

```bash
# 1. Abra a pasta no VS Code
code mechanix/

# 2. Instale a extensão "Live Server" (ritwickdey.LiveServer)
# 3. Clique com botão direito em index.html → "Open with Live Server"
```

### Opção 2 — servidor local via Node.js

```bash
# Instalar dependência (apenas uma vez)
npm install -g serve

# Rodar o projeto
serve mechanix/

# Acesse: http://localhost:3000
```

### Opção 3 — servidor via Python (sem instalar nada)

```bash
cd mechanix/
python3 -m http.server 3000

# Acesse: http://localhost:3000
```

> **Não abra index.html diretamente pelo navegador (file://).**
> Os scripts são carregados de forma modular e precisam de um servidor HTTP.

---

## Como conectar dados reais

Os dados estão centralizados em `js/data.js`.
Para conectar uma API, substitua os arrays por chamadas `fetch()`:

```js
// Exemplo: substituir DATA.clientes por uma API REST
async function loadClientes() {
  const res  = await fetch('/api/clientes');
  const json = await res.json();
  DATA.clientes = json;
}
```

Chame `loadClientes()` antes de inicializar as páginas em `app.js`.

---

## Como adicionar uma nova página

1. Crie `js/pages/novapage.js`
2. Registre a página:

```js
registerPage('novapage', () => `<div>HTML da página</div>`);

function init_novapage() {
  // lógica após inserção no DOM
}
```

3. Adicione o item na sidebar em `index.html`:

```html
<div class="nav-item" onclick="goTo('novapage',this)" data-label="Nova Página">
  <span class="nav-icon">🔧</span>Nova Página
</div>
```

4. Inclua o script no `index.html`:

```html
<script src="js/pages/novapage.js"></script>
```

---

## Stack sugerida para produção

| Camada     | Sugestão                          |
|------------|-----------------------------------|
| Frontend   | React + Vite + Tailwind           |
| Backend    | Node.js + Express ou NestJS       |
| Banco      | PostgreSQL (via Supabase ou RDS)  |
| Auth       | Supabase Auth ou NextAuth         |
| Deploy     | Vercel (frontend) + Railway (API) |

---

## Dependências externas (CDN)

- Google Fonts — Barlow + Barlow Condensed
- Chart.js 4.4.1 — gráficos de faturamento

Nenhum gerenciador de pacotes necessário para rodar.
